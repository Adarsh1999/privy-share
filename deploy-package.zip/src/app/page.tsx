import { PrivyApp } from "@/components/privy-app";

export default function Home() {
  return <PrivyApp />;
}
